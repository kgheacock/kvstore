An attempt towards simple tests for CSE 138.

At the moment, this is designed for assignment 4, with an extremely unittest, whose purpose is
primarily to exercise the network partition code.
